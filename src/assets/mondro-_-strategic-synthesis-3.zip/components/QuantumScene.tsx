
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, Torus, Cylinder, Stars, Environment, Box } from '@react-three/drei';
import * as THREE from 'three';

// Proxy components to avoid R3F intrinsic type issues
const AmbientLight = 'ambientLight' as any;
const PointLight = 'pointLight' as any;
const SpotLight = 'spotLight' as any;
const Group = 'group' as any;
const MeshStandardMaterial = 'meshStandardMaterial' as any;

const QuantumParticle = ({ position, color, scale = 1 }: { position: [number, number, number]; color: string; scale?: number }) => {
  const ref = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.getElapsedTime();
      ref.current.position.y = position[1] + Math.sin(t * 1.5 + position[0]) * 0.15;
      ref.current.rotation.x = t * 0.4;
      ref.current.rotation.z = t * 0.2;
    }
  });

  return (
    <Sphere ref={ref} args={[1, 32, 32]} position={position} scale={scale}>
      <MeshDistortMaterial
        color={color}
        envMapIntensity={0.8}
        clearcoat={1}
        clearcoatRoughness={0.1}
        metalness={0.8}
        distort={0.3}
        speed={1.5}
      />
    </Sphere>
  );
};

export const HeroScene: React.FC = () => {
  return (
    <div className="absolute inset-0 z-0 opacity-40 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 7], fov: 45 }}>
        {/* Fix: use proxy component for ambientLight */}
        <AmbientLight intensity={0.2} />
        {/* Fix: use proxy component for pointLight */}
        <PointLight position={[10, 10, 10]} intensity={1.5} color="#0099CC" />
        <Float speed={1.2} rotationIntensity={0.1} floatIntensity={0.2}>
          <QuantumParticle position={[0, 0, 0]} color="#0099CC" scale={1.8} />
        </Float>
        
        <Float speed={1.8} rotationIntensity={0.4} floatIntensity={0.6}>
           <QuantumParticle position={[-4, 2, -3]} color="#8B5CF6" scale={0.7} />
           <QuantumParticle position={[4, -2, -4]} color="#0099CC" scale={0.8} />
        </Float>

        <Environment preset="night" />
        <Stars radius={100} depth={50} count={2000} factor={4} saturation={0} fade speed={0.5} />
      </Canvas>
    </div>
  );
};

export const QuantumComputerScene: React.FC = () => {
  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
        {/* Fix: use proxy component for ambientLight */}
        <AmbientLight intensity={0.5} />
        {/* Fix: use proxy component for spotLight */}
        <SpotLight position={[5, 10, 5]} angle={0.2} penumbra={1} intensity={3} color="#0099CC" />
        <Environment preset="studio" />
        
        <Float rotationIntensity={0.2} floatIntensity={0.1} speed={1}>
          {/* Fix: use proxy component for group */}
          <Group position={[0, 0.5, 0]}>
            {/* Top Plate */}
            <Cylinder args={[1.3, 1.3, 0.05, 64]} position={[0, 1.2, 0]}>
              {/* Fix: use proxy component for meshStandardMaterial */}
              <MeshStandardMaterial color="#ffffff" metalness={0.9} roughness={0.1} />
            </Cylinder>
            
            {/* Middle Stage */}
            <Cylinder args={[1, 1, 0.05, 64]} position={[0, 0.4, 0]}>
              {/* Fix: use proxy component for meshStandardMaterial */}
              <MeshStandardMaterial color="#ffffff" metalness={0.9} roughness={0.1} />
            </Cylinder>
            
            {/* Mixing Chamber */}
            <Cylinder args={[0.7, 0.7, 0.05, 64]} position={[0, -0.4, 0]}>
              {/* Fix: use proxy component for meshStandardMaterial */}
              <MeshStandardMaterial color="#ffffff" metalness={0.9} roughness={0.1} />
            </Cylinder>

            {/* Silver Rods */}
            {[0.6, -0.6].map(x => (
              <Cylinder key={x} args={[0.02, 0.02, 1.6, 16]} position={[x, 0.4, 0]}>
                 {/* Fix: use proxy component for meshStandardMaterial */}
                 <MeshStandardMaterial color="#0099CC" metalness={1} roughness={0} />
              </Cylinder>
            ))}

            {/* Glow Core */}
            <Sphere args={[0.3, 32, 32]} position={[0, -0.8, 0]}>
               {/* Fix: use proxy component for meshStandardMaterial */}
               <MeshStandardMaterial color="#0099CC" emissive="#0099CC" emissiveIntensity={2} />
            </Sphere>
          </Group>
        </Float>
      </Canvas>
    </div>
  );
}
