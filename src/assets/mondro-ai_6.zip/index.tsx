/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { GoogleGenAI } from '@google/genai';
import React, { useState, useCallback, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';

import { Artifact, Session } from './types';
import { INITIAL_PLACEHOLDERS } from './constants';
import { generateId } from './utils';

import DottedGlowBackground from './components/DottedGlowBackground';
import ArtifactCard from './components/ArtifactCard';
import SideDrawer from './components/SideDrawer';
import { 
    ThinkingIcon, 
    CodeIcon, 
    SparklesIcon, 
    ArrowLeftIcon, 
    ArrowRightIcon, 
    ArrowUpIcon, 
    GridIcon 
} from './components/Icons';

// --- PREMIUM HIGH-VISIBLE ASSETS ---

const TechnicalAsset = () => (
  <div className="dimension-asset-premium technical-perspective-asset">
    <div className="pedestal-glow tech-glow-primary"></div>
    <svg viewBox="0 0 500 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: '100%', height: '100%' }}>
        <defs>
            <filter id="hyper-glow" x="-100%" y="-100%" width="300%" height="300%">
                <feGaussianBlur stdDeviation="15" result="blur" />
                <feColorMatrix in="blur" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 20 -10" result="glow" />
                <feComposite in="SourceGraphic" in2="glow" operator="over" />
            </filter>
            <filter id="frosted-glass" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feSpecularLighting surfaceScale="8" specularConstant="1" specularExponent="40" lightingColor="#ffffff" in="blur" result="spec">
                    <fePointLight x="250" y="150" z="150" />
                </feSpecularLighting>
                <feComposite in="SourceGraphic" in2="spec" operator="arithmetic" k1="0" k2="1" k3="1" k4="0" />
            </filter>
            <linearGradient id="fiber-bundle-grad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="transparent" />
                <stop offset="10%" stopColor="rgba(79, 209, 237, 0.4)" />
                <stop offset="50%" stopColor="white" />
                <stop offset="90%" stopColor="rgba(167, 139, 250, 0.4)" />
                <stop offset="100%" stopColor="transparent" />
            </linearGradient>
            <clipPath id="core-clip">
                <rect x="-45" y="-45" width="90" height="90" rx="15" transform="rotate(45)" />
            </clipPath>
        </defs>

        {/* Deep Circuit Grid Layer */}
        <g opacity="0.1" stroke="#4fd1ed" strokeWidth="0.5">
            {[...Array(12)].map((_, i) => (
                <path key={`grid-h-${i}`} d={`M 0 ${i * 40} H 500`} strokeDasharray="2 20" />
            ))}
            {[...Array(12)].map((_, i) => (
                <path key={`grid-v-${i}`} d={`M ${i * 40} 0 V 400`} strokeDasharray="2 20" />
            ))}
        </g>

        {/* Bundled Energy Paths - Fiber Optic Style */}
        <g className="fiber-paths">
            {/* Main Primary Bundle */}
            <g opacity="0.6">
                <path d="M 480 120 C 350 120, 320 180, 250 200 S 150 280, 20 280" stroke="#4fd1ed" strokeWidth="20" opacity="0.05" fill="none" />
                <path d="M 480 120 C 350 120, 320 180, 250 200 S 150 280, 20 280" stroke="url(#fiber-bundle-grad)" strokeWidth="6" strokeLinecap="round" fill="none" className="energy-streak streak-1" />
                <path d="M 480 120 C 350 120, 320 180, 250 200 S 150 280, 20 280" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" strokeDasharray="4 60" className="data-bit-flow" />
            </g>

            {/* Sub Bundle 1 */}
            <g opacity="0.4">
                <path d="M 480 140 C 360 140, 330 190, 250 200 S 140 260, 20 260" stroke="#a78bfa" strokeWidth="4" strokeLinecap="round" fill="none" className="energy-streak streak-2" />
                <path d="M 480 140 C 360 140, 330 190, 250 200 S 140 260, 20 260" stroke="white" strokeWidth="1" strokeLinecap="round" fill="none" strokeDasharray="2 40" className="data-bit-flow-fast" />
            </g>

            {/* Symmetry Bundle */}
            <g opacity="0.5">
                <path d="M 20 120 C 150 120, 180 180, 250 200 S 350 280, 480 280" stroke="url(#fiber-bundle-grad)" strokeWidth="6" strokeLinecap="round" fill="none" className="energy-streak streak-rev" />
                <path d="M 20 120 C 150 120, 180 180, 250 200 S 350 280, 480 280" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" strokeDasharray="4 80" className="data-bit-flow-rev" />
            </g>
        </g>

        {/* High-Fidelity 3D Glass Stack */}
        <g transform="translate(250, 200)">
            {/* Bottom Support Panel */}
            <rect x="-100" y="-100" width="200" height="200" rx="36" fill="rgba(255,255,255,0.01)" stroke="rgba(255,255,255,0.05)" transform="rotate(45)" className="stack-l1" />
            
            {/* Middle Logic Refraction Layer */}
            <g className="stack-l2">
                <rect x="-80" y="-80" width="160" height="160" rx="28" fill="rgba(79, 209, 237, 0.04)" stroke="rgba(79, 209, 237, 0.2)" transform="rotate(45)" style={{ filter: 'url(#frosted-glass)' }} />
                {/* Circuit Traces on Middle Layer */}
                <g stroke="#4fd1ed" strokeWidth="0.75" opacity="0.4" transform="rotate(45)">
                    <path d="M -60 -60 L -30 -30 M 60 60 L 30 30 M -60 60 L -30 30 M 60 -60 L 30 -30" className="trace-blink" />
                    <circle cx="-60" cy="-60" r="1.5" fill="#4fd1ed" />
                    <circle cx="60" cy="60" r="1.5" fill="#4fd1ed" />
                </g>
            </g>

            {/* Core Processor Housing */}
            <g className="stack-l3">
                <rect x="-50" y="-50" width="100" height="100" rx="18" fill="rgba(10, 10, 15, 0.98)" stroke="#4fd1ed" strokeWidth="2" transform="rotate(45)" style={{ filter: 'url(#hyper-glow)' }} />
                
                {/* Internal Quantum Activity */}
                <g clipPath="url(#core-clip)">
                    {/* Activity Matrix Cells */}
                    {[...Array(4)].map((_, i) => (
                        [...Array(4)].map((__, j) => (
                            <rect 
                                key={`cell-${i}-${j}`} 
                                x={-32 + i * 18} y={-32 + j * 18} 
                                width="12" height="12" rx="3" 
                                fill={i === j ? "#ffffff" : (i + j) % 2 === 0 ? "#4fd1ed" : "#a78bfa"} 
                                className="activity-cell" 
                                style={{ animationDelay: `${(i + j) * 0.15}s` }}
                            />
                        ))
                    ))}
                </g>

                {/* Sweeping Refractive Sheen */}
                <rect x="-120" y="-40" width="240" height="15" fill="rgba(255,255,255,0.2)" transform="rotate(-45)" className="glass-sheen" />
            </g>
        </g>
    </svg>
  </div>
);

const VisualAsset = () => (
  <div className="dimension-asset-premium">
    <div className="pedestal-glow" style={{ background: 'radial-gradient(ellipse, #a78bfa 0%, transparent 70%)' }}></div>
    <svg viewBox="0 0 500 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: '100%', height: '100%' }}>
        <defs>
            <filter id="prismatic-blur" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="15" />
            </filter>
            <linearGradient id="prism-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#a78bfa" />
                <stop offset="50%" stopColor="#f472b6" />
                <stop offset="100%" stopColor="#60a5fa" />
            </linearGradient>
        </defs>

        {/* Layered Prismatic Rings */}
        <circle cx="250" cy="200" r="120" stroke="url(#prism-grad)" strokeWidth="1" opacity="0.1" />
        
        <g style={{ transformOrigin: '250px 200px', animation: 'orbit-rotate 25s infinite linear' }}>
            <rect x="175" y="125" width="150" height="150" rx="40" stroke="url(#prism-grad)" strokeWidth="2" opacity="0.5">
                <animate attributeName="stroke-dasharray" values="10,20;40,10;10,20" dur="8s" repeatCount="indefinite" />
            </rect>
        </g>

        <g style={{ transformOrigin: '250px 200px', animation: 'orbit-rotate 15s infinite linear reverse' }}>
            <circle cx="250" cy="200" r="80" stroke="#f472b6" strokeWidth="1" strokeDasharray="5 15" opacity="0.4" />
            <path d="M250 120 L270 140 M230 140 L250 120" stroke="white" strokeWidth="2" opacity="0.8" />
        </g>

        {/* Center Glow */}
        <circle cx="250" cy="200" r="40" fill="url(#prism-grad)" opacity="0.2" style={{ filter: 'url(#prismatic-blur)' }} />
        <circle cx="250" cy="200" r="10" fill="white" style={{ animation: 'core-vibrate 2s infinite' }} />
    </svg>
  </div>
);

const UXAsset = () => (
  <div className="dimension-asset-premium">
    <div className="pedestal-glow" style={{ background: 'radial-gradient(ellipse, #f472b6 0%, transparent 70%)' }}></div>
    <svg viewBox="0 0 500 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: '100%', height: '100%' }}>
        {/* Dynamic Circuit Paths */}
        <path d="M100 200 C 150 100, 350 300, 400 200" stroke="rgba(244, 114, 182, 0.2)" strokeWidth="2" fill="none" />
        <path d="M100 200 C 150 100, 350 300, 400 200" stroke="#f472b6" strokeWidth="4" strokeLinecap="round" strokeDasharray="1 20" fill="none" style={{ animation: 'dash-scroll 4s infinite linear' }} />
        
        <path d="M100 250 C 180 350, 320 50, 400 150" stroke="rgba(167, 139, 250, 0.1)" strokeWidth="1" fill="none" />
        <path d="M100 250 C 180 350, 320 50, 400 150" stroke="#a78bfa" strokeWidth="3" strokeLinecap="round" strokeDasharray="1 30" fill="none" style={{ animation: 'dash-scroll 6s infinite linear reverse' }} />

        {/* Interactive Nodes */}
        <g>
            <circle cx="100" cy="200" r="6" fill="#f472b6">
                <animate attributeName="r" values="5;8;5" dur="3s" repeatCount="indefinite" />
            </circle>
            <circle cx="250" cy="200" r="6" fill="#ffffff" opacity="0.8" />
            <circle cx="400" cy="200" r="6" fill="#4fd1ed" />
        </g>

        {/* Floating User Particles */}
        <circle r="3" fill="white">
            <animateMotion path="M100 200 C 150 100, 350 300, 400 200" dur="2s" repeatCount="indefinite" />
        </circle>
        <circle r="2" fill="white" opacity="0.5">
            <animateMotion path="M100 250 C 180 350, 320 50, 400 150" dur="3.5s" repeatCount="indefinite" />
        </circle>
    </svg>
  </div>
);

const AudienceAsset = () => (
  <div className="dimension-asset-premium">
    <div className="pedestal-glow" style={{ background: 'radial-gradient(ellipse, #10b981 0%, transparent 70%)' }}></div>
    <svg viewBox="0 0 500 400" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: '100%', height: '100%' }}>
        {/* Sonar Ripples */}
        <circle cx="250" cy="200" r="10" stroke="#10b981" strokeWidth="2">
            <animate attributeName="r" from="10" to="180" dur="4s" repeatCount="indefinite" />
            <animate attributeName="opacity" from="0.8" to="0" dur="4s" repeatCount="indefinite" />
        </circle>
        <circle cx="250" cy="200" r="10" stroke="#10b981" strokeWidth="2">
            <animate attributeName="r" from="10" to="180" dur="4s" begin="2s" repeatCount="indefinite" />
            <animate attributeName="opacity" from="0.8" to="0" dur="4s" begin="2s" repeatCount="indefinite" />
        </circle>

        {/* Reticle / Focus Brackets */}
        <g opacity="0.6" stroke="#10b981" strokeWidth="2">
            {/* Top-Left */}
            <path d="M180 150 V130 H200" style={{ animation: 'core-vibrate 2s infinite' }} />
            {/* Top-Right */}
            <path d="M320 150 V130 H300" style={{ animation: 'core-vibrate 2s infinite' }} />
            {/* Bottom-Left */}
            <path d="M180 250 V270 H200" style={{ animation: 'core-vibrate 2s infinite' }} />
            {/* Bottom-Right */}
            <path d="M320 250 V270 H300" style={{ animation: 'core-vibrate 2s infinite' }} />
        </g>

        {/* Central "Truth" Point */}
        <circle cx="250" cy="200" r="5" fill="#10b981" />
        <path d="M250 180 V220 M230 200 H270" stroke="#10b981" strokeWidth="1" opacity="0.4" />
    </svg>
  </div>
);

const DIMENSIONS = [
  { id: 'tech', title: 'TECHNICAL FOUNDATION', desc: 'Checks how your website behaves in real conditions: load speed, stability, mobile responsiveness, and core search-readiness signals.', Asset: TechnicalAsset, tags: ['SPEED', 'STABILITY', 'MOBILE', 'SEO/GEO'] },
  { id: 'visual', title: 'VISUAL CLARITY', desc: 'Assessing visual language, hierarchy, balance, and first impression to understand how clearly your message comes across.', Asset: VisualAsset, tags: ['HIERARCHY', 'LAYOUT', 'CONTRAST', 'CREDIBILITY'] },
  { id: 'ux', title: 'UX USER FLOW', desc: 'Reviews navigation logic and interaction patterns to assess how easily visitors complete key actions.', Asset: UXAsset, tags: ['NAVIGATION', 'EFFORT', 'PATH', 'ACTION'] },
  { id: 'audience', title: 'POSITIONING CLARITY', desc: 'Evaluates whether your messaging resonates with your audience and clearly positions your offer as relevant and credible.', Asset: AudienceAsset, tags: ['RELEVANCE', 'VALUE', 'TRUST', 'FOCUS'] }
];

interface ProtocolCardProps {
  dim: any;
  idx: number;
  key?: React.Key;
}

function ProtocolCard({ dim, idx }: ProtocolCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setIsVisible(true); observer.unobserve(entry.target); }
    }, { threshold: 0.15 });
    if (cardRef.current) observer.observe(cardRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={cardRef} className={`protocol-glass-card ${idx % 2 === 1 ? 'reverse' : ''} ${isVisible ? 'is-visible' : ''}`}>
      <div className="dim-visual-container">
          <dim.Asset />
      </div>
      <div className="dim-text-container">
          <h3>{dim.title}</h3>
          <p>{dim.desc}</p>
          <div className="dim-tags">
              {dim.tags.map((tag: string) => (
                  <span key={tag} className="tag">
                      <span className="tag-dot"></span>
                      {tag}
                  </span>
              ))}
          </div>
      </div>
    </div>
  );
}

const CheckIcon = () => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M15 4.5L6.75 12.75L3 9" stroke="#7C3AED" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

function PricingSection() {
    return (
        <section className="pricing-section">
            <div className="section-header">
                <h2>Clear data. Strategic growth.</h2>
                <p className="section-desc">Whether you need a one-time diagnostic or a continuous improvement engine, we have a plan for your stage of growth.</p>
            </div>
            
            <div className="pricing-grid">
                <div className="pricing-card">
                    <div className="pricing-header">
                        <h3>Snapshot</h3>
                        <div className="price">$149 <span className="period">one-time</span></div>
                        <p className="price-meta">One site. One moment in time. No subscription.</p>
                        <p className="pricing-desc">A single, comprehensive assessment that tells you exactly where your site stands and what to fix first.</p>
                    </div>
                    <ul className="pricing-features">
                        <li><CheckIcon /> Expert diagnostic</li>
                        <li><CheckIcon /> Decision-grade assessment</li>
                        <li><CheckIcon /> Board-ready report (PDF)</li>
                    </ul>
                    <button className="pricing-btn secondary">Get Single Scan</button>
                </div>

                <div className="pricing-card popular">
                    <div className="popular-badge">POPULAR</div>
                    <div className="pricing-header">
                        <h3>Improvement</h3>
                        <div className="price">$49 <span className="period">/mo</span></div>
                        <p className="price-meta">Billed quarterly. Cancel anytime.</p>
                        <p className="pricing-desc">Ongoing insight and prioritisation so every change you make is intentional and measurable.</p>
                    </div>
                    <ul className="pricing-features">
                        <li><CheckIcon /> <b>Track score evolution</b></li>
                        <li><CheckIcon /> <b>Validate improvements</b></li>
                        <li><CheckIcon /> <b>Benchmarking</b></li>
                        <li><CheckIcon /> <b>Slack Alerts</b></li>
                    </ul>
                    <button className="pricing-btn primary">Start Free Trial</button>
                </div>

                <div className="pricing-card">
                    <div className="pricing-header">
                        <h3>Scale</h3>
                        <div className="price">$99 <span className="period">/mo</span></div>
                        <p className="price-meta">Per seat. Volume discounts available.</p>
                        <p className="pricing-desc">A unified diagnostic framework for teams and agencies managing multiple websites.</p>
                    </div>
                    <ul className="pricing-features">
                        <li><CheckIcon /> Client-facing credibility</li>
                        <li><CheckIcon /> Repeatable framework</li>
                        <li><CheckIcon /> White-label Reports</li>
                    </ul>
                    <button className="pricing-btn secondary">Contact Sales</button>
                </div>
            </div>
        </section>
    );
}

function Footer() {
    return (
        <footer className="footer">
            <div className="footer-top">
                <div className="footer-brand">
                    <div className="logo">mondro<span className="dot"></span></div>
                    <p>See how good your website really is.</p>
                </div>
                
                <div className="footer-links-grid">
                    <div className="footer-col">
                        <h4>Product</h4>
                        <a href="#">Features</a>
                        <a href="#">Pricing</a>
                        <a href="#">Enterprise</a>
                        <a href="#">Roadmap</a>
                    </div>
                    <div className="footer-col">
                        <h4>Resources</h4>
                        <a href="#">Blog</a>
                        <a href="#">Case Studies</a>
                        <a href="#">Documentation</a>
                        <a href="#">Help Center</a>
                    </div>
                    <div className="footer-col">
                        <h4>Company</h4>
                        <a href="#">About Us</a>
                        <a href="#">Careers</a>
                        <a href="#">Legal</a>
                        <a href="#">Contact</a>
                    </div>
                </div>

                <div className="footer-cta">
                    <h4>Stay updated</h4>
                    <p>Get the latest insights on AI and web performance.</p>
                    <div className="newsletter-form">
                        <input type="email" placeholder="Email address" />
                        <button><ArrowRightIcon /></button>
                    </div>
                </div>
            </div>
            
            <div className="footer-bottom">
                <div className="footer-socials">
                    <a href="#" className="social-link">X</a>
                    <a href="#" className="social-link">LinkedIn</a>
                </div>
                <p className="copyright">© 2025 Mondro Inc.</p>
            </div>
        </footer>
    );
}

function App() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [currentSessionIndex, setCurrentSessionIndex] = useState<number>(-1);
  const [focusedArtifactIndex, setFocusedArtifactIndex] = useState<number | null>(null);
  const [inputValue, setInputValue] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [drawerState, setDrawerState] = useState<{ isOpen: boolean; mode: 'code' | 'variations' | null; title: string; data: any; }>({ isOpen: false, mode: null, title: '', data: null });

  const inputRef = useRef<HTMLInputElement>(null);
  const heroInputRef = useRef<HTMLInputElement>(null);

  const hasStarted = sessions.length > 0 || isLoading;

  useEffect(() => {
    if (!hasStarted) heroInputRef.current?.focus();
    else inputRef.current?.focus();
  }, [hasStarted]);

  useEffect(() => {
    const interval = setInterval(() => setPlaceholderIndex(p => (p + 1) % INITIAL_PLACEHOLDERS.length), 4000);
    return () => clearInterval(interval);
  }, []);

  const handleSendMessage = useCallback(async (manualPrompt?: string) => {
    const promptToUse = manualPrompt || inputValue;
    const trimmedInput = promptToUse.trim();
    if (!trimmedInput || isLoading) return;
    setInputValue('');
    setIsLoading(true);

    const sessionId = generateId();
    const placeholderArtifacts: Artifact[] = Array(4).fill(null).map((_, i) => ({
        id: `${sessionId}_${i}`, styleName: 'Thinking...', html: '', status: 'streaming'
    }));

    const newSession: Session = { id: sessionId, prompt: trimmedInput, timestamp: Date.now(), artifacts: placeholderArtifacts };
    setSessions(prev => [...prev, newSession]);
    setCurrentSessionIndex(sessions.length); 

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const styleResponse = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Generate 4 professional audit perspective names for site "${trimmedInput}" (Technical, Visual, UX, Strategy). Return JSON array strings only.`
        });

        let generatedStyles = DIMENSIONS.map(d => d.title);
        try {
            const match = styleResponse.text?.match(/\[.*\]/s);
            if (match) generatedStyles = JSON.parse(match[0]);
        } catch (e) {}

        const generateArtifact = async (artifact: Artifact, perspective: string) => {
            const streamAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const stream = await streamAi.models.generateContentStream({
                model: 'gemini-3-pro-preview',
                contents: `Act as a world-class web auditor. Audit: "${trimmedInput}". Perspective: ${perspective}. Generate a high-end dashboard component (HTML/Tailwind). Glassmorphism, interactive charts, dark theme.`,
            });
            let html = '';
            for await (const chunk of stream) {
                html += chunk.text || '';
                setSessions(prev => prev.map(s => s.id === sessionId ? {
                    ...s, artifacts: s.artifacts.map(art => art.id === artifact.id ? { ...art, html, styleName: perspective } : art)
                } : s));
            }
            const cleanHtml = html.replace(/```html|```/g, '').trim();
            setSessions(prev => prev.map(s => s.id === sessionId ? {
                ...s, artifacts: s.artifacts.map(art => art.id === artifact.id ? { ...art, html: cleanHtml, status: 'complete' } : art)
            } : s));
        };
        await Promise.all(placeholderArtifacts.map((art, i) => generateArtifact(art, generatedStyles[i] || DIMENSIONS[i].title)));
    } catch (e) {
        console.error("API Error:", e);
    } finally { setIsLoading(false); }
  }, [inputValue, isLoading, sessions.length]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => { if (e.key === 'Enter') handleSendMessage(); };
  const currentSession = sessions[currentSessionIndex];

  return (
    <div className="immersive-app">
        <DottedGlowBackground gap={24} radius={1.2} color="rgba(255, 255, 255, 0.02)" glowColor="rgba(167, 139, 250, 0.15)" speedScale={0.3} />
        
        <div className={`landing-nav ${hasStarted ? 'fade-out' : ''}`}>
            <div className="logo">mondro<span className="dot"></span></div>
            <div className="nav-actions">
                <a href="#" className="signup-btn">Get Started</a>
            </div>
        </div>

        <div className={`stage-container ${!hasStarted ? 'landing-scroll' : ''}`}>
            {!hasStarted ? (
                <div className="landing-page">
                    <section className="hero-section">
                        <h1>Websites succeed or<br/>fail in seconds.</h1>
                        <p className="hero-subtext">Mondro analyzes your digital presence using multi-dimensional AI logic to surface conversion bottlenecks.</p>
                        <div className="hero-input-container">
                            <div className="input-wrapper">
                                <input ref={heroInputRef} type="text" placeholder={INITIAL_PLACEHOLDERS[placeholderIndex]} value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={handleKeyDown} />
                                <button className="hero-send-btn" onClick={() => handleSendMessage()}><ArrowRightIcon /></button>
                            </div>
                        </div>
                    </section>

                    <section className="protocol-section">
                        <div className="section-header">
                            <h2>OUR PROTOCOL</h2>
                            <p className="section-desc">
                                People do not experience websites in parts. They experience them as a whole. 
                                In seconds, they sense credibility, relevance, speed, clarity, and ease. 
                                Most tools break this experience into fragments and miss the big picture. 
                                Mondro brings it back together, showing where confidence forms, where it fades, 
                                and why decisions never happen.
                            </p>
                        </div>
                        <div className="protocol-list">
                            {DIMENSIONS.map((dim, idx) => <ProtocolCard key={dim.id} dim={dim} idx={idx} />)}
                        </div>
                    </section>

                    <PricingSection />
                    <Footer />
                </div>
            ) : (
                <div className="artifact-grid">
                    {currentSession?.artifacts.map((artifact, aIndex) => (
                        <ArtifactCard key={artifact.id} artifact={artifact} isFocused={focusedArtifactIndex === aIndex} onClick={() => setFocusedArtifactIndex(aIndex)} />
                    ))}
                </div>
            )}
        </div>

        <div className={`command-center ${hasStarted ? 'visible' : ''}`}>
            <div className="command-dock">
                <div className={`command-toolbar ${focusedArtifactIndex !== null ? 'active' : ''}`}>
                    <div className="active-meta-info">
                        <span className="meta-prompt">{currentSession?.prompt}</span>
                        {focusedArtifactIndex !== null && <span className="meta-perspective"> // {currentSession?.artifacts[focusedArtifactIndex]?.styleName}</span>}
                    </div>
                    <div className="command-actions-group">
                        <button className="command-btn" onClick={() => setFocusedArtifactIndex(null)}><GridIcon /> <span>Grid</span></button>
                        <button className="command-btn" onClick={() => setDrawerState({ isOpen: true, mode: 'variations', title: 'Variations', data: null })}><SparklesIcon /> <span>Variations</span></button>
                        <button className="command-btn" onClick={() => setDrawerState({ isOpen: true, mode: 'code', title: 'Source', data: currentSession?.artifacts[focusedArtifactIndex!]?.html })}><CodeIcon /> <span>Source</span></button>
                    </div>
                </div>
                
                {focusedArtifactIndex === null && (
                    <div className="dock-input-wrapper">
                        <div className="input-wrapper">
                            <input ref={inputRef} type="text" value={inputValue} placeholder="Scan another URL..." onChange={(e) => setInputValue(e.target.value)} onKeyDown={handleKeyDown} disabled={isLoading} />
                            {isLoading && <ThinkingIcon />}
                            <button className="send-button" onClick={() => handleSendMessage()} disabled={isLoading || !inputValue.trim()}><ArrowUpIcon /></button>
                        </div>
                    </div>
                )}
            </div>
        </div>

        <SideDrawer isOpen={drawerState.isOpen} onClose={() => setDrawerState(s => ({...s, isOpen: false}))} title={drawerState.title}>
            {drawerState.mode === 'code' ? <pre className="code-block"><code>{drawerState.data}</code></pre> : <div style={{color: 'white', padding: '24px'}}>Advanced Variation Engine Loading...</div>}
        </SideDrawer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
