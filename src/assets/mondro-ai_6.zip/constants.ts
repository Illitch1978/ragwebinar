/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export const INITIAL_PLACEHOLDERS = [
    "yourwebsite.com",
    "google.com",
    "apple.com",
    "Enter a URL to audit...",
    "stripe.com",
    "framer.com",
    "airbnb.com"
];